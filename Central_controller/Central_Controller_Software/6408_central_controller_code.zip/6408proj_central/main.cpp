/*
ME 6408 Final Project
Central Controller for the clock
Using Real Time Operating System
*/

#include "mbed.h"
#include "rtos.h"
#include "SDFileSystem.h"
#include "wave_player.h"
#define MAX_SPN_SIZE 29
#include <vector>
#include <sstream>

//#include "uLCD_4DGL.h"
Serial pc(USBTX,USBRX);
Serial SPN(p28, p27); // tx, rx, debug serial
Serial arduino(p9, p10); // flip clock
Serial xbee(p13,p14);     // spining LED

SDFileSystem sd(p5, p6, p7, p8, "sd"); //SD card

//uLCD_4DGL lcd(p13, p14, p15);

AnalogOut DACout(p18);
wave_player waver(&DACout);

DigitalIn button4(p21);
DigitalIn button3(p22);
DigitalIn button2(p23);
DigitalIn button1(p24);

DigitalOut debugLED1(LED1);
DigitalOut debugLED2(LED2);
DigitalOut debugLED3(LED3);
DigitalOut debugLED4(LED4);

Mutex Sound_mutex;

int day,month,year,hour,minute,second,hour_spin,minute_spin,del_hour,del_min, offset_hour, offset_min;

int spin_LED_mode=9;
int chg_mode_cmd_counter=0; //how many times header has been sent, ie,"#MOD,3,0,0"
int button1_counter = 0;


int button_lock = 0;
int DisplayCalendar = 1;
int delta_day, delta_month, delta_year;
int StopRotation = 0;
int color = 6;

int temp_mode;

int flag_setting = 1;

/*
void sound_thread(void const *args) {
    
    while (true) {
        Sound_mutex.lock();
        FILE *wave_file;
        wave_file=fopen("/sd/wavfiles/BUZZER.wav","r");
        waver.play(wave_file);
        fclose(wave_file);
        Thread::wait(1000);
        Sound_mutex.unlock();
    }
}
*/


//Thread read push buttons
void push_button_thread(void const *args) {
    while (true) {
        
        if(button1==0 && button_lock==0 )   
        {
            color = (color+1)%7 + 1;
            
            if(color==1)
            {
                xbee.printf("#COL,1,0,0\n");
            }
            else if(color==2)
            {
                xbee.printf("#COL,2,0,0\n");
            }
            else if(color==3)
            {
                xbee.printf("#COL,3,0,0\n");
            }
            else if(color==4)
            {
                xbee.printf("#COL,4,0,0\n");
            }
            else if(color==5)
            {
                xbee.printf("#COL,5,0,0\n");
            }
            else if(color==6)
            {
                xbee.printf("#COL,6,0,0\n");
            }
            else if(color==7)
            {
                xbee.printf("#COL,7,0,0\n");
            }
            
            /*
            if (button1_counter ==0)
            {
                debugLED1 = 0;
                debugLED3 = 0;
                debugLED4 = 0;
                DisplayCalendar = 1;
                StopRotation = 0;
                xbee.printf("#STP,0,0,0\n");
            }
            else if (button1_counter ==1)
            {
                debugLED1 = 1;
                debugLED3 = 0;
                debugLED4 = 0;
                DisplayCalendar = 0;
                StopRotation = 0;
                xbee.printf("#STP,0,0,0\n");
            }
            else if (button1_counter ==2)
            {
                debugLED1 = 0;
                debugLED3 = 1;
                debugLED4 = 1;
                StopRotation = 1;
                xbee.printf("#STP,1,0,0\n");
            }
            button1_counter = (button1_counter+1)%3;
            */
        }        
        else if(button2==0 && button_lock==0 ) 
        {         
             debugLED2 = !debugLED2;
             
             if(flag_setting==1)
             {
                 //spin_LED_mode = (spin_LED_mode+1)%11;
                 spin_LED_mode = (spin_LED_mode+1)%10;
             }
             else if (flag_setting==0)
             {
                 //temp_mode = (temp_mode+1)%9;
                 temp_mode = (temp_mode+1)%8;
                 spin_LED_mode = temp_mode+2;
             }
             
             button_lock = 1;
             
             if (spin_LED_mode==0)
             {
                xbee.printf("#MOD,0,0,0\n");
             }
             else if (spin_LED_mode==1)
             {
                xbee.printf("#MOD,1,0,0\n");
             }
             else if (spin_LED_mode==2)
             {
                xbee.printf("#MOD,2,0,0\n");
             }
             else if (spin_LED_mode==3)
             {
                xbee.printf("#MOD,3,0,0\n");
             }
             else if (spin_LED_mode==4)
             {
                xbee.printf("#MOD,4,0,0\n");
             }
             else if (spin_LED_mode==5)
             {
                xbee.printf("#MOD,5,0,0\n");
             }
             else if (spin_LED_mode==6)
             {
                xbee.printf("#MOD,6,0,0\n");
             }
             else if (spin_LED_mode==7)
             {
                xbee.printf("#MOD,7,0,0\n");
             }
             else if (spin_LED_mode==8)
             {
                xbee.printf("#MOD,8,0,0\n");
             }
             else if (spin_LED_mode==9)
             {
                xbee.printf("#MOD,9,0,0\n");
             }
             else if (spin_LED_mode==10)
             {
                xbee.printf("#MOD,10,0,0\n");
             }
        }
        else if(button3==0 && button_lock==0)   
        {
            if(spin_LED_mode == 0  && flag_setting==1)
            {
                del_hour = del_hour+1;
            }
            else if(spin_LED_mode == 1  && flag_setting==1)
            {
                time_t seconds = time(NULL);
                set_time(seconds+3600);
            }
            else if(spin_LED_mode == 5)
            {
                delta_month = delta_month+1;
            }
            /*
                //StopRotation = 1;
                //xbee.printf("#STP,1,0,0\n");
                //debugLED3 = !debugLED3;            
                time_t seconds = time(NULL);
            
                if(spin_LED_mode == 2 || spin_LED_mode == 3 || spin_LED_mode == 4)
                {
                    set_time(seconds+3600);
                }
                else if(spin_LED_mode == 5)
                {
                    delta_month = delta_month+1;
                }*/
            
        }
        else if(button4==0 && button_lock==0)   
        {
            if(spin_LED_mode == 0 && flag_setting==1)
            {
                del_min = del_min+1;
            }
            else if(spin_LED_mode == 1 && flag_setting==1)
            {
                time_t seconds = time(NULL);
                set_time(seconds+60);
            }
            else if(spin_LED_mode == 5)
            {
                delta_day = delta_day+1;
            }
            /*
            {
                //StopRotation = 1;
                //xbee.printf("#STP,1,0,0\n");
                //debugLED4 = !debugLED4;           
                time_t seconds = time(NULL);
            
                if(spin_LED_mode == 2 || spin_LED_mode == 3 || spin_LED_mode == 4)
                {
                    set_time(seconds+60);
                }
                else if(spin_LED_mode == 5)
                {
                    delta_day = delta_day+1;
                }
            }*/
        }
        else 
        {
            button_lock = 0;
        }
        Thread::wait(200);
    }
}


//Read time from real-time clock
void RTC_thread(void const *args) {
    while (true) {
        time_t seconds = time(NULL);

        char buffer[40];
        strftime(buffer,40, "%d %m %Y.%H:%M:%S\n", localtime(&seconds));
        
        day=(buffer[0]-48)*10+(buffer[1]-48) + delta_day;
        month=(buffer[3]-48)*10+(buffer[4]-48) + delta_month;
        year=(buffer[6]-48)*1000+(buffer[7]-48)*100+(buffer[8]-48)*10+(buffer[9]-48) + delta_year;
        hour_spin=(buffer[11]-48)*10+(buffer[12]-48);
        minute_spin=(buffer[14]-48)*10+(buffer[15]-48);
        second=(buffer[17]-48)*10+(buffer[18]-48);
        
        if(spin_LED_mode==0 && flag_setting==1)
        {
            hour = del_hour%24;
            minute = del_min%60;
        }
        else if (spin_LED_mode==1 && flag_setting==1 )
        {            
            offset_hour = del_hour%24-hour_spin;
            offset_min = del_min%60-minute_spin;
        }
        else if (spin_LED_mode>1)
        {
            hour = hour_spin+offset_hour;
            minute = minute_spin + offset_min;    
            
            if (del_min!=0)
            {
                if(flag_setting==1)
                {
                    temp_mode = -1;
                }
                flag_setting = 0;
            }       
        }
        
        month = month%12;
        if (month==0)
        {
            month = 12;
        }
        else if (month==1 || month==3 || month==5 || month==7 || month==8 || month==10 || month==12)
        {
            day = day%31;
            if (day==0)
            {
                day = 31;
            } 
        }
        else if (month==2)
        {
            if(year%4==0)
            {
                day = day%29;
                if (day==0)
                {
                    day = 29;
                } 
            }
            else
            {
                day = day%28;
                if (day==0)
                {
                    day = 28;
                } 
            }
        }
        else
        {
            day = day%30;
            if (day==0)
            {
                day = 30;
            } 
        }
              
        Thread::wait(100);
    }
}

//send commands to peripherals
void communication_thread(void const *args) {
    while (true) {
        //send command to flip clock
        arduino.printf("%d,%d,%d\n",hour,minute,second);
        
        //send command to spin LED
        if (spin_LED_mode==1 || spin_LED_mode==2 || spin_LED_mode==3 || spin_LED_mode==4)
        {            
            xbee.printf("#HMS,%d,%d,%d\n",hour_spin,minute_spin,second); 
         }          
        else if (spin_LED_mode==5)
        {        
            xbee.printf("#YMD,%d,%d,%d\n",year,month,day);         
        }
        Thread::wait(300);
    }
}


void setup(){
    
    set_time(1459123200);  // Set RTC time to 3/28/2016 0:00
}

int main(){
    setup();
    
    Thread t1(RTC_thread);
    Thread t2(push_button_thread);
    //Thread t3(sound_thread);
    Thread t4(communication_thread);
    
    while (true) {
        Thread::wait(500);
    }
}
